function [LP,LS,chi2,p,dim,time1,time2,shan_ent,P_out ] = LS_measure_latent_entropy_dbmr(Xi,Xj)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
tic;[ContigencyTable,chi2,p]=crosstab(Xj,Xi);
SS1=sum(sum(ContigencyTable));
SS=sum(ContigencyTable,2);SS=SS./sum(SS);
ContigencyTable_norm=ContigencyTable./SS1;
time1=toc;
%time2=0;
tic;
N_anneal=2;
T=sum(sum(ContigencyTable));
[I,J]=size(ContigencyTable);
P=zeros(I,J,J);
EV_measure=zeros(1,J);
LogL=zeros(1,J);
IC=zeros(1,J);
if I>1
ind_J=1:J;%[1:min(J-1,10) J];%
else
ind_J=[1];
end
for k=ind_J
    if k==J
        for i=1:J
            P(:,i,k)=ContigencyTable(:,i)/sum(ContigencyTable(:,i));
        end
        N_param(k)=(I-1)*J;
    elseif k==1
        S=sum(ContigencyTable,2);S=S./sum(S);
        for i=1:I
            P(i,:,k)=S(i)*ones(1,J);
        end
        N_param(k)=(I-1);
    else
        for t=1:N_anneal
            %tic;
            %[prob_term_topic, prob_topic_doc,lls] = DBMR_clustering(ContigencyTable_norm, k);
            [prob_term_topic, prob_topic_doc,lls] = plsa(ContigencyTable_norm, k);
            %time2=time2+toc;

            if t==1
                P(:,:,k)=prob_term_topic*prob_topic_doc;
                ll=lls(length(lls));
            else
                if lls(length(lls))>ll
                    P(:,:,k)=prob_term_topic*prob_topic_doc;
                    ll=lls(length(lls));
                end
            end
        end
        N_param(k)=(I-1)*k;%+(k-1)*J;
    end
    for state_i=1:I
        Log_entropy(state_i)=0;
        for state_j1=1:J
            for state_j2=1:J
                EV_measure(k)=EV_measure(k)+(P(state_i,state_j1,k)-P(state_i,state_j2,k)).^2;
            end
            if P(state_i,state_j1,k)>0
               LogL(k)=LogL(k)+ContigencyTable(state_i,state_j1)*log(P(state_i,state_j1,k));
               Log_entropy(state_i)=Log_entropy(state_i)+P(state_i,state_j1,k)*log(P(state_i,state_j1,k));
            end
        end
    end
EV_measure(k)=-LogL(k)./SS1;%EV_measure(k)/((2*J-2)*I);-sum(Log_entropy);%
IC(k)=-2*LogL(k)+2*N_param(k)+(N_param(k)+1)/(T-N_param(k)-1);%+N_param(k)*log(T);%
end

[min_IC,dim]=min(IC(ind_J));
PosteriorProbability=exp(-0.5*(IC(ind_J)-min_IC))./sum(exp(-0.5*(IC(ind_J)-min_IC)));
P_out=zeros(size(P,1),size(P,2));
for k=1:length(PosteriorProbability)
    P_out=P_out+PosteriorProbability(k)*P(:,:,k);
end
LP=1-PosteriorProbability(1);
%if J>=3
%    LP=PosteriorProbability(2:(J-1));
%else
%    LP=0;
%end
%LS=sum(EV_measure(ind_J).*PosteriorProbability)/EV_measure(1);%EV_measure(J);%
S0=-sum(sum(ContigencyTable.*log(1/(I*J))))./SS1;
LS=sum(EV_measure(ind_J).*PosteriorProbability);
dim=(sum(PosteriorProbability.*ind_J)-1)/(J-1);
shan_ent=EV_measure(1);
time2=toc;
end

