%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%
%% Code reproducing the comparison of Landau-Lifschit-Ginzburg data analysis results
%% Requires following MATLAB-Toolboxes: "Parallel Computing" and "Image Processing"
%% 
%% Implemented in 2020 by I. Horenko
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear all
close all
addpath('ProgramFiles')
addpath('Data')

Nbins=2;
randn('seed',3)
rand('seed',3)

%% Select type of the measurement noise (between 'gaussian' and 'nongaussian') and noise variance sigma 
noise_type='nongaussian';
%sigma=0.0;
sigma=0.1;
%% Load magnetisation data from file as a 3D Matlab array (variable spin)
%% Please upload the data-file 'LandauLifschitz_Magnetization_Mx' from
%% https://www.dropbox.com/s/vkpvsy246v8s5da/LandauLifschitz_Magnetization_Mx.mat?dl=0
load('LandauLifschitz_Magnetization_Mx');
%% Impose artificial measurement noise on magnetisation data
spin=create_image_noise(spin,sigma,noise_type);
[N,M,T]=size(spin);
%% Compute common relation measures (mean and autocorrelation)
for i=1:size(spin,1);
    for j=1:size(spin,2);
        cc=corrcoef(spin(i,j,1:size(spin,3)-1),spin(i,j,2:size(spin,3)));
        CC(i,j)=cc(1,2);
        Mean(i,j)=mean(squeeze(spin(i,j,:)));
    end;
end
%% Discretize the data
E=reshape(spin,1,N*M*T);
E = discretize(E,Nbins);
spin0=spin;
spin=reshape(E,[N M T]);
%% Compute latent relation measures
[out] = LS_Filter2D_seq(spin);
%% Visualise the results
[numSpinsPerDim_X,numSpinsPerDim_Y]=size(spin(:,:,1));
FS=24;FS2=20;gap=[0.04 0.04];
line_low=[22 22];line_high=[43 43];marg_h=0.1;marg_w=0.05;
figure;set(gcf,'Position',[10 100 1300  350])
subtightplot(1,3,1,gap,marg_h,marg_w);imagesc(smooth2(Mean));title('temporal mean','FontSize',FS);colorbar;axis off
hold on;plot([1 64]',line_low','r:','LineWidth',8);plot([1 64]',line_high','r:','LineWidth',8);
xlim([2 numSpinsPerDim_X-1]);ylim([2 numSpinsPerDim_Y-1]);set(gca,'FontSize',FS2)
subtightplot(1,3,2,gap,marg_h,marg_w);imagesc(smooth2(CC));title('temporal autocorrelation','FontSize',FS);colorbar;axis off
hold on;plot([1 64]',line_low','r:','LineWidth',8);plot([1 64]',line_high','r:','LineWidth',8);
xlim([2 numSpinsPerDim_X-1]);ylim([2 numSpinsPerDim_Y-1]);colorbar;axis off;set(gca,'FontSize',FS2)
subtightplot(1,3,3,gap,marg_h,marg_w);imagesc(smooth2(out.LS));title('expected latent entropy','FontSize',FS)
hold on;plot([1 64]',line_low','r:','LineWidth',8);plot([1 64]',line_high','r:','LineWidth',8);
xlim([2 numSpinsPerDim_X-1]);ylim([2 numSpinsPerDim_Y-1]);colorbar;axis off;set(gca,'FontSize',FS2)%caxis([min(min(out.LS(2:numSpinsPerDim_X-1,2:numSpinsPerDim_Y-1))) max(max(out.LS(2:numSpinsPerDim_X-1,2:numSpinsPerDim_Y-1)))]) 
