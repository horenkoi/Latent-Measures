function [J_noise]=create_image_noise(J,sigma,noise_type)
%% sigma is the desired image noise variance
%% J,J_noise - output movies (origanal and with noise) as 3D vectors
J_noise=0*J;
for t=1:size(J,3)
    if strcmp(noise_type,'gaussian')
        J_noise(:,:,t)=imnoise(J(:,:,t),'gaussian',0,sigma);
    elseif strcmp(noise_type,'nongaussian')
        J_noise(:,:,t)=imnoise(J(:,:,t),'speckle',sigma);
    else
        disp('This noise type is not supported - please change the variable noise_type appropriately.');
    end
    %J_noise(:,:,t)=imnoise(J(:,:,t),'speckle',sigma);
end
