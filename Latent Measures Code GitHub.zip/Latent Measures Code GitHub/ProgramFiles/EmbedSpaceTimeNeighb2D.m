function [Y_emb,X_emb]=EmbedSpaceTimeNeighb2D(X,i,j,Time_Lag,flag);
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
[I,J,T]=size(X);
Y=[];
above = mod(i - 1, I) + 1;
below = mod(i, I) + 1;
left  = mod(j - 1, J) + 1;
right = mod(j, J) + 1;
neighbors=[];
if flag>0
    for ind_t=1:Time_Lag+1
        neighbors = [neighbors;  ...
            %squeeze(X(below,right,Time_Lag+2-ind_t:T-ind_t+1))';...
            %squeeze(X(below,left,Time_Lag+2-ind_t:T-ind_t+1))';...
            %squeeze(X(above,right,Time_Lag+2-ind_t:T-ind_t+1))';...
            %squeeze(X(above,left,Time_Lag+2-ind_t:T-ind_t+1))';...
            squeeze(X(above,j,Time_Lag+2-ind_t:T-ind_t+1))';...
            squeeze(X(i,left,Time_Lag+2-ind_t:T-ind_t+1))';...
            squeeze(X(i,right,Time_Lag+2-ind_t:T-ind_t+1))';...%...
            squeeze(X(below,j,Time_Lag+2-ind_t:T-ind_t+1))'];
        %if ind_t>1
        neighbors = [neighbors;squeeze(X(i,j,Time_Lag+2-ind_t:T-ind_t+1))'];
        %end
    end
else
    for ind_t=1:Time_Lag+1
         %if ind_t>1
        neighbors = [neighbors;squeeze(X(i,j,Time_Lag+2-ind_t:T-ind_t+1))'];
        %end
    end
end
if flag>0
Y_emb=squeeze(X(i,j,Time_Lag+1:T))';
[X_emb]= EmbedCategoricalVect(neighbors);
else
Y_emb=squeeze(X(i,j,1:T))';
X_emb=squeeze(X(i,j,1:T))';
end
end

