function [out] = LS_Filter2D_seq(spin,TTT,Domain)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
flag=1;
ParalleBlockSize=1000;
[I,J]=size(spin(:,:,1));
if nargin==1
    TTT=size(spin,3);
    ind_t=1:TTT-1;
end
if nargin<3
    Domain=zeros(I,J);
    Domain(floor(I/4):floor(3*I/4),floor(J/4):floor(3*J/4))=1;
end
if nargin>1
   ind_t=randperm(size(spin,3)-1);
   ind_t=ind_t(1:TTT);   
end
out.Mean=zeros(I,J);out.LS=zeros(I,J);out.CHI2=zeros(I,J);out.P=zeros(I,J);
Time_Lag=0;
k=1;
for i=1:I
    i
    for j=1:J
        [Y_emb{k},X_emb{k}]=EmbedSpaceTimeNeighb2D(spin,i,j,Time_Lag,flag);
        out.Mean(i,j)=mean(Y_emb{k});
        ind_i{k}=i;ind_j{k}=j;
        k=k+1;
        if or(mod(k,ParalleBlockSize)==0,and(mod(k,ParalleBlockSize)~=0,and(i==I,j==J)))
            %T=length(Y_emb{1});
            disp('Starting parallel computation in a data block...')
            parfor ii=1:k-1
                %[~,ls{ii},chi2{ii},p{ii},dim{ii} ] = LS_measure_latent_entropy_dbmr(Y_emb{ii}(2:TTT),Y_emb{ii}(1:TTT-1));
%                [~,ls{ii},chi2{ii},p{ii},dim{ii} ] = LS_measure_latent_entropy_dbmr(X_emb{ii}(ind_t+1),X_emb{ii}(ind_t));
                [~,ls{ii},chi2{ii},p{ii},dim{ii} ] = LS_measure_latent_entropy_dbmr(X_emb{ii}(1+Time_Lag:TTT-Time_Lag-1),X_emb{ii}(2+Time_Lag:TTT-Time_Lag));
                %[~,ls{ii},chi2{ii},p{ii},dim{ii} ] = LS_measure_latent_entropy_dbmr(X_emb{ii}(1+Time_Lag:TTT-Time_Lag-1),Y_emb{ii}(2+Time_Lag:TTT-Time_Lag));
                cc{ii}=corrcoef(X_emb{ii}(1+Time_Lag:TTT-Time_Lag-1),X_emb{ii}(2+Time_Lag:TTT-Time_Lag));
            end
            for ii=1:k-1
                out.LS(ind_i{ii},ind_j{ii})=ls{ii};
                out.CHI2(ind_i{ii},ind_j{ii})=chi2{ii};
                out.CC(ind_i{ii},ind_j{ii})=cc{ii}(1,2);
                out.P(ind_i{ii},ind_j{ii})=p{ii};
                out.DIM(ind_i{ii},ind_j{ii})=dim{ii};
            end
            disp('...complete')
            k=1;
        end
    end
end

%imagesc(bw);
%out.bw = activecontour(out.LS, Domain,'Chan-Vese','SmoothFactor',0.5);
%out.bwJ = activecontour(Domain, Domain,'Chan-Vese','SmoothFactor',0.5);
%out.bwM = activecontour(out.Mean, Domain,'Chan-Vese','SmoothFactor',0.5);
%out.bwCC = activecontour(out.CC, Domain,'Chan-Vese','SmoothFactor',0.5);
%out.bwCHI2 = activecontour(out.CHI2, Domain,'Chan-Vese','SmoothFactor',0.5);
%if nargin>2
%out.err=min_err_auc(out.bw,out.bwJ);
%out.errM=min_err_auc(out.bwM,out.bwJ);
%out.errCC=min_err_auc(out.bwCC,out.bwJ);
%out.errCHI2=min_err_auc(out.bwCHI2,out.bwJ);
%end
end

