function W = smooth2(X)
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here
W(1,:,:)=X;W = smooth3(W,'gauss',[1 3 3]);
W=squeeze(W(1,:,:));
end

